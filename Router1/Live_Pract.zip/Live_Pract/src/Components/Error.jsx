export const Error = () => {
  return <div>!Oops ! Error Page</div>;
};
