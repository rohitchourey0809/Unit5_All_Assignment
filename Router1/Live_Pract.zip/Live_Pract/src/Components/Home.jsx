export const HOME = () => {
  return <div>Welcome To Home</div>;
};
