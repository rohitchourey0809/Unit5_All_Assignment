const app = require("./index")
const connet = require("./config/db")
const port = 8080


app.listen(port, async function()
{
    try {
        await connet()
        console.log(`server working on ${port}`)
    } catch (error) {
        console.log(error.message)
    }
});