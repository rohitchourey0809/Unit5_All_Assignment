const mongoose = require("mongoose")

module.exports = ()=>{
    return mongoose.connect("mongodb+srv://mehra1024:2JPNdjUjzPBA0abc@cluster0.m18dy.mongodb.net/myTodo")
}


//password;= 2JPNdjUjzPBA0abc
// use  = mehra1024
