const mongoose = require("mongoose");
const express = require ("express");
var jwt = require('jsonwebtoken');
const User = require("../models/User.model")
require('dotenv').config()

const register = async (req,res)=>{
    try {
        
    } catch (error) {
        
    }
}